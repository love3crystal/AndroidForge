# CLAUDE.md

Project-level guidance for Claude Code when working in this repository. Read this before making changes.

## Project overview

An **open-source Android calculator** inspired by Mi Calculator (`com.miui.calculator` by Xiaomi Inc.). Goal: a modern, fully-offline, multi-purpose calculator with basic + scientific math, a unit converter, and life calculators (loan/EMI, GST, BMI, age, discount, date diff). Ad-free, no analytics, no network calls. It declares only the floating calculator permissions (see **Permissions declared** under [Things to know](#things-to-know-gotchas)). Apache 2.0 licensed, published to GitHub.

See [REQUIREMENTS.md](REQUIREMENTS.md) for the full product specification - it is the source of truth for scope and non-functional targets.

## Tech stack (locked decisions)

| Area | Choice |
|---|---|
| Language | Kotlin 2.x (K2 compiler) |
| Min SDK | **API 31** (Android 12) - chosen so Material You dynamic color, native SplashScreen, and modern motion/shape are first-class with no compat branching |
| Target SDK | **API 36** (Android 16) |
| Compile SDK | **API 37** - required by the AndroidX/Compose artifacts in use (they declare a minCompileSdk of 37). Independent of `targetSdk`, which stays at 36 until the Android 17 behavior changes are reviewed and device-tested. |
| UI | Jetpack Compose + Material 3 with **Material 3 Expressive** components |
| Architecture | MVVM, single-activity, unidirectional data flow |
| Navigation | Navigation Compose with **type-safe routes** (serializable route classes) |
| DI | Hilt |
| Async | Kotlin Coroutines + Flow |
| Persistence | Room (history, recent unit pairs) + DataStore Preferences (user settings and per-tool memory) |
| Network | None. App is fully offline; no `INTERNET` permission. It declares only the floating calculator permissions (see [Things to know](#things-to-know-gotchas)). |
| Math engine | Custom evaluator: `BigDecimal` for arithmetic, bounded `Double` with rounding for transcendentals (sin/cos/log/exp). Revisit BigMath-style libs only if precision bugs appear. |
| Build | Gradle Kotlin DSL, **Version Catalogs** (`gradle/libs.versions.toml`), R8 minification + resource shrinking on release |
| Performance | AndroidX Startup for lightweight init |
| Widgets | Jetpack **Glance** (not legacy RemoteViews) |
| Splash | AndroidX SplashScreen API + adaptive icon |
| Testing | **JUnit5** (unit, via `android-junit5` plugin), **JUnit4 + Robolectric** (Compose UI tests on the JVM), Turbine, MockK. No instrumented tests yet |
| Static analysis | ktlint + detekt + Android Lint (error severity) |
| CI | GitHub Actions |
| Distribution | Google Play (AAB), Play App Signing |

If you need to change any of the locked decisions above, raise the trade-off explicitly with the user before editing code or the requirements doc.

## Project layout

Everything ships from a **single Gradle module (`:app`)**. The `feature/` and `core/` directories are Kotlin **packages**, not Gradle modules - the app build script notes they can be promoted to library modules later if build times or isolation demand it. "Module" in the rules below means "package boundary" until that split happens.

```
app/
  src/main/java/com/calculator/
    feature/            # User-facing features: screens and their ViewModels
      basic/            # Basic calculator (ui/)
      math/             # percent/ - percentage calculator
      converter/        # unit/ converter + base/ (number-base) converter
      finance/          # loan/, gst/, discount/, profit/, investment/, deposit/, salary/, tipsplit/
      health/           # bmi/, ovulation/
      datetime/         # age/, datediff/, timezone/
      history/          # calculation history sheet
      tape/             # running tape/paper-roll view
      floating/         # floating overlay calculator (foreground service)
      settings/         # settings + about sheet
    core/
      math/             # Expression parser + evaluator (pure Kotlin, no Android deps); di/
      data/             # Room DB, DAOs, DataStore (history/, converter/, settings/, tape/, db/, di/)
      domain/           # Pure Kotlin calculators (converter/, datetime/, health/, math/, finance/)
      designsystem/     # theme/ (colors, typography) + component/ (scaffold, cards, fields, date picker)
      common/           # format/ and clipboard/ helpers
      widget/           # Glance home-screen widget + Quick Settings tile
    navigation/         # App shell: CalculatorNavHost, routes, tools menu, launcher shortcuts
    CalculatorApplication.kt
    MainActivity.kt
```

Keep features self-contained. **A `feature/` package imports only `core/`** - never another feature, never `navigation/` and never `MainActivity`. Shared UI goes to `core/designsystem/component`. `navigation/` is the app shell: it is the only package that knows every feature, hosts the one tools menu, and wires features together through callbacks (screens take `onOpenMenu`). CI fails a feature that breaks this rule. Scientific functions route through `core/math`; there is no separate scientific feature package.

## Coding style and conventions

### Comments and KDoc

This is an open-source project; readability for new contributors matters more than for a private codebase. **Override the default "no comments" stance** and follow this:

- **KDoc on every public class, object, interface, and top-level function.** Lead with one short sentence describing purpose; add `@param`/`@return`/`@throws` where non-obvious.
- **KDoc on non-trivial public methods.** Skip getters/setters and one-liners whose name fully describes them.
- **Inline comments only where the WHY is non-obvious** - hidden constraints, workarounds, surprising invariants, references to specs (e.g. "Shunting-Yard handles left-associativity here").
- **Do not** describe WHAT the code does when the names already do.
- **Do not** add change-log style comments ("added for issue #42", "used by X") - those belong in PR descriptions and git history.

### Naming

- Use Kotlin idiomatic names: `PascalCase` for classes, `camelCase` for functions/properties, `SCREAMING_SNAKE_CASE` for top-level `const val`.
- Composables: `PascalCase` (e.g. `BasicCalculatorScreen`).
- ViewModels: `<Feature>ViewModel` (e.g. `BasicCalculatorViewModel`).
- UI state classes: `<Feature>UiState`. UI events: `<Feature>UiEvent`.

### Architecture rules

- **ViewModels expose `StateFlow<UiState>`**, never `LiveData`, never mutable state to the UI.
- UI is **stateless** where possible; hoist state to ViewModel.
- **Repositories return `Flow`** for observable data and `suspend fun` for one-shots.
- **Use cases are pure Kotlin** (no Android deps) and live under `core/domain/` when shared, otherwise inside the feature.
- **No `runBlocking` in production code.** Tests may use `runTest`.

### Compose specifics

- Prefer `collectAsStateWithLifecycle()` over `collectAsState()`.
- Pass primitive parameters down; avoid passing whole ViewModels into deep composables.
- Use **stable** data classes for state; mark unstable types with `@Stable`/`@Immutable` only when justified.
- Previews live next to their composable, annotated with `@PreviewLightDark` (or a custom multi-preview annotation).

### Math engine

- Arithmetic precision: use `BigDecimal` with `MathContext.DECIMAL64` unless a feature explicitly needs more or less.
- Transcendentals (sin/cos/log/exp): operate on `Double`, then round to the configured decimal precision before returning a `BigDecimal`.
- Reject division by zero with a typed error (`EvaluationResult.Error.DivisionByZero`), never throw across the API boundary.
- The engine is **pure Kotlin** - no Android imports, fully unit-testable on JVM.

## User preferences (apply everywhere)

These come from the user's global preferences and apply to every commit, file, and chat reply in this repo:

- **Never use em dash (`-`) or en dash (`-`).** Always use a regular ASCII hyphen (`-`). Applies to code comments, commit messages, doc files, PR descriptions, chat replies.
- **Never add `Co-Authored-By: Claude` (or any other Claude/Anthropic attribution)** to commit messages, PR descriptions, or any git artifact. The user maintains repos under their own name.

## Common commands

```bash
# Build debug
./gradlew :app:assembleDebug

# Build release (R8-shrunk AAB)
./gradlew :app:bundleRelease

# Install on connected device/emulator
./gradlew :app:installDebug

# Unit tests (JVM; includes Robolectric-backed Compose UI tests - no emulator needed)
./gradlew test
./gradlew testDebugUnitTest          # single variant, faster

# Run a single test class or method (Gradle test filter)
./gradlew testDebugUnitTest --tests "com.calculator.core.math.EvaluatorTest"
./gradlew testDebugUnitTest --tests "com.calculator.core.math.EvaluatorTest.divides by zero returns error"
./gradlew testDebugUnitTest --tests "com.calculator.feature.*"   # glob a package

# Static analysis
./gradlew ktlintCheck
./gradlew detekt
./gradlew lint

# Format code with ktlint
./gradlew ktlintFormat
```

**Testing notes:**
- Unit tests use **JUnit5 (Jupiter)** as the engine; Robolectric tests are JUnit4 and run through the **vintage engine** in the same `test` task. Don't split them into separate runs.
- **Compose UI tests run headless on the JVM** via `createComposeRule()` + Robolectric - they execute under `./gradlew test`, not `connectedAndroidTest`. Reserve instrumented tests for things that genuinely need a device.
- **Kotest property tests** (e.g. `EvaluatorPropertyTest`) call `checkAll` directly inside `@org.junit.jupiter.api.Test` bodies. Don't add the `kotest-runner-junit5` plugin - layering a second engine breaks discovery.

## Things to know (gotchas)

- **GST and Deposits (FD, RD, PPF) are India-specific.** They are offered only when the locale country is IN or the time zone is India's (`isIndia` in `navigation/Tools.kt`, the one tool list for the menu and launcher shortcuts). Never hardcode it as universally available; new India-only tools use the same check.
- **Loan/EMI calculator: use neutral language.** Google Play's personal-loans policy bans wording that implies the app is a lender. Strings must read as a calculator, not a lending tool.
- **No network calls.** The app is fully offline. Don't add a network library or the `INTERNET` permission without an explicit conversation about the trade-off - the offline story is part of the app's positioning.
- **Permissions declared** (the manifest is no longer zero-permissions; the floating-calculator feature pulls these in):
  - `SYSTEM_ALERT_WINDOW` - draw the floating overlay over other apps. User-granted via system settings.
  - `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE` - host the overlay in a foreground service so it survives leaving the app (SPECIAL_USE is the catch-all type required on API 34+).
  - `POST_NOTIFICATIONS` - the foreground service's ongoing notification on API 33+.
  The merged manifest also gets `WAKE_LOCK`, `ACCESS_NETWORK_STATE` and `RECEIVE_BOOT_COMPLETED` from AndroidX WorkManager (the Glance widget uses it to schedule updates; no network calls are made) and the signature permission `in.co.gorest.calculator.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` from AndroidX. No INTERNET, location, or contacts. Don't add permissions for new features without raising the trade-off with the user first.
- **Locale decimal separator.** Parse and render numbers per-locale (`,` in many EU locales, `.` in US/IN). The math engine accepts both via a locale-aware formatter at the UI boundary - the engine itself works on canonical `.`-separated strings.
- **No crash reporter.** The app has none. Adding one needs an explicit opt-in toggle in Settings, off by default, and an update to PRIVACY.md. Do not wire up Crashlytics or Firebase without it.
- **No analytics in v1.** Do not add Firebase Analytics, no third-party SDKs that phone home.
- **Backups.** Android Auto Backup is on; nothing sensitive is stored, but `data_extraction_rules.xml` is authored explicitly so the policy is reviewable (the old `backup_rules.xml` was ignored on API 31+ and is gone). Health tools such as ovulation are never saved as recent tools.

## Working with the requirements doc

[REQUIREMENTS.md](REQUIREMENTS.md) is the product spec. Treat it as load-bearing:

- When a decision changes (new library, dropped feature, version bump), **update REQUIREMENTS.md in the same change** that makes the technical change.
- Tech-stack rows in this CLAUDE.md must stay in sync with the stack table in REQUIREMENTS.md - update both together.
- When unsure about scope, defer to REQUIREMENTS.md over assumptions.

## When in doubt

- **Prefer editing existing files over creating new ones.**
- **Don't add abstractions for hypothetical futures.** A single calculator doesn't need an interface; three of them might.
- **Don't add error handling for impossible states.** Validate at boundaries (user input, network), trust internal calls.
- **Ask before** deleting branches, force-pushing, dropping DB tables, or bumping major dependencies.
