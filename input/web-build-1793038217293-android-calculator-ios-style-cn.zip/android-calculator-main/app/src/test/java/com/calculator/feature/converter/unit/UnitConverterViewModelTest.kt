package com.calculator.feature.converter.unit

import androidx.lifecycle.SavedStateHandle
import com.calculator.core.data.converter.UnitConverterRepository
import com.calculator.core.data.settings.UserSettings
import com.calculator.core.domain.converter.ConversionTable
import com.calculator.core.domain.converter.UnitCategory
import com.calculator.testing.FakeSettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.CsvSource
import java.util.Locale

/**
 * Tests the conversion + UI-state semantics: typing into "from", picking
 * different units, swap, category change, and recent-pair recall.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class UnitConverterViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private val repo = FakeRepo()
    private val settings = FakeSettingsRepository(UserSettings(precision = 6))
    private lateinit var viewModel: UnitConverterViewModel

    @BeforeEach
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        viewModel = UnitConverterViewModel(repo, settings, SavedStateHandle())
    }

    @AfterEach
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `typing in the from field updates the to output`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            // Default pair for Length: m -> km (units[0] vs units[1]).
            viewModel.setFromInput("1000")
            advanceUntilIdle()
            assertEquals("1", viewModel.state.value.toText)
        }

    @Test
    fun `picking a different to-unit recomputes`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            viewModel.setFromInput("1")
            val mile = ConversionTable.unitsFor(UnitCategory.Length).single { it.symbol == "mi" }
            viewModel.setToUnit(mile)
            advanceUntilIdle()
            // 1 m -> mile is 6.21371e-4. At precision 6 we render the
            // first 6 significant figures as "0.000621371".
            val out = viewModel.state.value.toText
            assertTrue(out.startsWith("0.000621"), "got $out")
        }

    @Test
    fun `swap exchanges units and shows the inverse`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            viewModel.setFromInput("1000")
            advanceUntilIdle()
            // Before swap: from = m, to = km. After swap: from = km, to = m
            // and the "from" field carries the previous output (1 km).
            viewModel.swap()
            advanceUntilIdle()
            assertEquals(
                "km",
                viewModel.state.value.fromUnit
                    ?.symbol,
            )
            assertEquals(
                "m",
                viewModel.state.value.toUnit
                    ?.symbol,
            )
            assertEquals("1", viewModel.state.value.fromText)
            // toOutput goes through NumberFormatter so the running
            // locale adds grouping ("1,000" in en-US, "1.000" in de-DE).
            // The unit test task pins the default locale to en-US.
            assertEquals("1,000", viewModel.state.value.toText)
        }

    @ParameterizedTest
    @CsvSource(
        "en-US, '1,000,000', '1,000', '1,000,000'",
        "de-DE, '1.000.000', '1.000', '1.000.000'",
        "en-IN, '10,00,000', '1,000', '10,00,000'",
    )
    fun `swap with a grouped result keeps the exact number`(
        tag: String,
        typedMetres: String,
        kilometres: String,
        metresBack: String,
    ) = runTest(dispatcher) {
        val saved = Locale.getDefault()
        Locale.setDefault(Locale.forLanguageTag(tag))
        try {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            viewModel.setFromInput(typedMetres)
            advanceUntilIdle()
            assertEquals(kilometres, viewModel.state.value.toText)

            viewModel.swap()
            advanceUntilIdle()
            assertEquals(kilometres, viewModel.state.value.fromText)
            assertEquals(metresBack, viewModel.state.value.toText)
        } finally {
            Locale.setDefault(saved)
        }
    }

    @Test
    fun `swap after typing in the to field keeps the typed value with its unit`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            viewModel.setToInput("1")
            advanceUntilIdle()
            assertEquals("1,000", viewModel.state.value.fromText)

            viewModel.swap()
            advanceUntilIdle()
            assertEquals(
                "km",
                viewModel.state.value.fromUnit
                    ?.symbol,
            )
            assertEquals("1", viewModel.state.value.fromText)
            assertEquals("1,000", viewModel.state.value.toText)
        }

    @Test
    fun `a decimal comma reads as a decimal in de-DE`() =
        runTest(dispatcher) {
            val saved = Locale.getDefault()
            Locale.setDefault(Locale.GERMANY)
            try {
                advanceUntilIdle()
                viewModel.selectCategory(UnitCategory.Length)
                advanceUntilIdle()
                viewModel.setFromInput("1500,5")
                advanceUntilIdle()
                assertEquals("1,5005", viewModel.state.value.toText)
            } finally {
                Locale.setDefault(saved)
            }
        }

    @Test
    fun `typed text comes back after process death`() =
        runTest(dispatcher) {
            viewModel.selectCategory(UnitCategory.Length)
            viewModel.setFromInput("2500")
            advanceUntilIdle()

            val handle = SavedStateHandle(mapOf("units.fromText" to "2500", "units.lastEdited" to "From"))
            val restored = UnitConverterViewModel(repo, settings, handle)
            advanceUntilIdle()
            assertEquals("2500", restored.state.value.fromText)
            assertEquals("2.5", restored.state.value.toText)
        }

    @Test
    fun `typing in the to field updates the from output (reverse direction)`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            // Default pair: m -> km. Type "1" into the To (km) side and
            // assert From (m) recomputes to the equivalent.
            viewModel.setToInput("1")
            advanceUntilIdle()
            assertEquals(UnitConverterUiState.PickerSide.To, viewModel.state.value.lastEdited)
            assertEquals("1,000", viewModel.state.value.fromText)
            assertEquals("1", viewModel.state.value.toText)
        }

    @Test
    fun `editing the from side after editing the to side flips lastEdited and recomputes`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            // First edit on the To side
            viewModel.setToInput("5")
            advanceUntilIdle()
            assertEquals(UnitConverterUiState.PickerSide.To, viewModel.state.value.lastEdited)
            assertEquals("5,000", viewModel.state.value.fromText)
            // User now edits the From side - lastEdited must flip back
            viewModel.setFromInput("2000")
            advanceUntilIdle()
            assertEquals(UnitConverterUiState.PickerSide.From, viewModel.state.value.lastEdited)
            assertEquals("2", viewModel.state.value.toText)
        }

    @Test
    fun `changing the to unit while the source is the to side recomputes from`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            viewModel.setToInput("1")
            advanceUntilIdle()
            assertEquals("1,000", viewModel.state.value.fromText) // 1 km -> 1000 m
            val mile = ConversionTable.unitsFor(UnitCategory.Length).single { it.symbol == "mi" }
            viewModel.setToUnit(mile)
            advanceUntilIdle()
            // 1 mi -> m is 1609.344. At precision 6 it renders with grouping.
            val out = viewModel.state.value.fromText
            assertTrue(out.startsWith("1,609"), "got $out")
        }

    @Test
    fun `empty to-input clears the from output`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            viewModel.setToInput("")
            advanceUntilIdle()
            assertEquals("", viewModel.state.value.fromText)
        }

    @Test
    fun `empty input emits an empty output`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Length)
            advanceUntilIdle()
            viewModel.setFromInput("")
            advanceUntilIdle()
            assertEquals("", viewModel.state.value.toText)
        }

    @Test
    fun `category change replaces unit list`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Temperature)
            advanceUntilIdle()
            val units = viewModel.state.value.units
            assertEquals(
                ConversionTable.unitsFor(UnitCategory.Temperature).map { it.symbol },
                units.map { it.symbol },
            )
        }

    @Test
    fun `recent pair is persisted on unit change`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            viewModel.selectCategory(UnitCategory.Mass)
            advanceUntilIdle()
            val lb = ConversionTable.unitsFor(UnitCategory.Mass).single { it.symbol == "lb" }
            viewModel.setToUnit(lb)
            advanceUntilIdle()
            assertEquals("kg" to "lb", repo.records[UnitCategory.Mass])
        }

    @Test
    fun `recent pair is recalled when reopening a category`() =
        runTest(dispatcher) {
            advanceUntilIdle()
            // Seed the repo as if a previous session saved this pair.
            repo.records[UnitCategory.Volume] = "L" to "gal US"
            viewModel.selectCategory(UnitCategory.Volume)
            advanceUntilIdle()
            assertEquals(
                "L",
                viewModel.state.value.fromUnit
                    ?.symbol,
            )
            assertEquals(
                "gal US",
                viewModel.state.value.toUnit
                    ?.symbol,
            )
        }

    private class FakeRepo : UnitConverterRepository {
        val records = mutableMapOf<UnitCategory, Pair<String, String>>()

        override suspend fun recent(category: UnitCategory): Pair<String, String>? = records[category]

        override suspend fun record(category: UnitCategory, fromSymbol: String, toSymbol: String) {
            records[category] = fromSymbol to toSymbol
        }
    }
}
