package com.calculator.core.math

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertInstanceOf
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.params.ParameterizedTest
import org.junit.jupiter.params.provider.CsvSource
import java.math.BigDecimal

/**
 * Golden-value test for [Evaluator]: a wide catalogue of (expression,
 * expected result) pairs run through the engine in a single fast JVM
 * pass.
 *
 * Purpose
 * -------
 * The targeted tests in [EvaluatorTest] and [ScientificEvaluatorTest]
 * are narrative - each one exercises a single property. This file is
 * the opposite: a flat catalogue that exists to catch regressions
 * across the whole surface of the engine at once. When a math bug
 * slips through (e.g. sin(π) returning 1.22e-16 instead of 0, or
 * 33...3 + 33...3 silently rounding to 16 sig figs), add a row here
 * so the same shape of bug can never come back.
 *
 * Conventions
 * -----------
 * - "Success" rows use [successCases] and compare values via
 *   [BigDecimal.compareTo] so a `1` result matches a `1.0` expectation.
 * - "Near" rows use [transcendentalCases] and assert |actual - expected|
 *   is below a tolerance, because trig / log / sqrt route through Double
 *   and the last digit is non-deterministic.
 * - "Error" rows use [errorCases] and assert the right [EvaluationResult.Error]
 *   subtype is returned.
 *
 * Why CsvSource not @MethodSource: a one-line addition is the lowest-
 * friction way to expand this catalogue, and the JUnit5 test names
 * already include the row's column 0 (the expression) so failures are
 * self-describing.
 */
class EvaluatorGoldenTest {
    private val rad = Evaluator(angleMode = AngleMode.Radian)
    private val deg = Evaluator(angleMode = AngleMode.Degree)

    // ------------------------------------------------------------------
    // Exact-success cases: the engine must return precisely this value.
    // ------------------------------------------------------------------

    @DisplayName("exact arithmetic")
    @ParameterizedTest(name = "{0} = {1}")
    @CsvSource(
        // basic
        "'0',                       0",
        "'1+1',                     2",
        "'2-3',                     -1",
        "'2×3',                     6",
        "'6÷2',                     3",
        "'-5',                      -5",
        "'-5+3',                    -2",
        // precedence
        "'1+2×3',                   7",
        "'(1+2)×3',                 9",
        "'2+3×4-5',                 9",
        "'10-2×3',                  4",
        "'20÷4÷5',                  1",
        // nested parens
        "'((2+3)×4)',               20",
        "'2×(3+(4-1))',             12",
        "'((1+2)+(3+4))',           10",
        // decimals (exact terminating)
        "'1.5+2.25',                3.75",
        "'0.1+0.2',                 0.3",
        "'1.5×4',                   6",
        "'0.5×0.5',                 0.25",
        "'10×0.1',                  1",
        // unary minus folded into a literal
        "'-3+5',                    2",
        "'-3×4',                    -12",
        "'-2×-3',                   6",
        // large-integer + - × must be EXACT (no DECIMAL64 rounding)
        "'33333333333333333333+33333333333333333333',   66666666666666666666",
        "'99999999999999999999-1',                       99999999999999999998",
        "'99999999999999999999×2',                       199999999999999999998",
        "'12345678901234567890×0',                       0",
        // a multiplication that would round under DECIMAL64
        "'9999999999×9999999999',                        99999999980000000001",
        // identity / zero
        "'0×123456789',             0",
        "'123456789×1',             123456789",
        "'0+0',                     0",
        "'1-1',                     0",
        // mixed operator chains
        "'1+2-3+4-5',               -1",
        "'2×3÷6',                   1",
        "'7÷2×2',                   7",
        // negative results
        "'5-10',                    -5",
        "'-(2+3)',                  -5",
        // factorial
        "'0!',                      1",
        "'1!',                      1",
        "'5!',                      120",
        "'10!',                     3628800",
        "'13!',                     6227020800",
        // sign flip composes with factorial: -(5!) NOT (-5)!
        "'-5!',                     -120",
        // power: integer cases
        "'2^0',                     1",
        "'2^10',                    1024",
        "'10^3',                    1000",
        // squared / cubed via the engine's symbol form
        "'3^2',                     9",
        "'4^3',                     64",
        // power right-associativity: 2^3^2 should be 2^(3^2) = 2^9 = 512,
        // NOT (2^3)^2 = 64. Standard math convention.
        "'2^3^2',                   512",
        "'3^2^2',                   81",
        // unary minus edge cases
        "'--5',                     5",
        "'---5',                    -5",
        "'-(2+3)',                  -5",
        "'-(-(2+3))',               5",
        "'2×-3',                    -6",
        "'-3×-2',                   6",
        "'5+-3',                    2",
        "'5--3',                    8",
        // -2^2 = -(2^2) = -4 (power binds tighter than unary minus)
        "'-2^2',                    -4",
        "'-2^3',                    -8",
        "'(-2)^2',                  4",
        "'(-2)^3',                  -8",
        // nested factorial: (5!)! is huge so don't go there; 3!! is
        // (3!)! = 6! = 720 by left-to-right reading (the engine
        // doesn't implement the math-double-factorial 3!! = 3×1)
        "'3!!',                     720",
        "'(2+3)!',                  120",
        "'5!+5',                    125",
        "'5!×2',                    240",
        "'5+5!',                    125",
        // percent
        "'5%',                      0.05",
        "'50%',                     0.5",
        "'100%',                    1",
        "'200+10%',                 200.1",
        "'5%×2',                    0.1",
        // long chains
        "'1+2+3+4+5+6+7+8+9+10',    55",
        "'1×2×3×4×5×6×7',           5040",
        "'1+1+1+1+1+1+1+1+1+1',     10",
        // deeply nested parens
        "'((((((1+1))))))',         2",
        "'(((1)))+(((2)))',         3",
        // number format
        "'.5',                      0.5",
        "'5.',                      5",
        "'.5+.5',                   1",
        "'0.5+0.5',                 1",
        // mixed operators with parens
        "'(1+2)×(3+4)',             21",
        "'(10-2)÷(2×2)',            2",
        "'2×(3+4)-5',               9",
        // larger factorials still in range
        "'15!',                     1307674368000",
        "'20!',                     2432902008176640000",
        // squared/cubed shortcuts
        "'5^2',                     25",
        "'5^3',                     125",
        "'10^2',                    100",
        // zero in various places
        "'0+5',                     5",
        "'5+0',                     5",
        "'5-0',                     5",
        "'5×0',                     0",
        "'0×5',                     0",
        "'0!',                      1",
        // power identity
        "'5^1',                     5",
        "'1^100',                   1",
        "'0^5',                     0",
        // left-associative subtraction / division
        "'1-2-3',                   -4",
        "'10-3-2',                  5",
        "'100÷5÷2',                 10",
        "'1000÷10÷10÷10',           1",
        // mixed signs
        "'-1-1',                    -2",
        "'-1+1',                    0",
        "'(-1)+(-1)',               -2",
        "'(-1)×(-1)',               1",
        "'(-1)^4',                  1",
        "'(-1)^5',                  -1",
        "'(-2)^4',                  16",
        // squared / cubed parens
        "'(2+3)^2',                 25",
        "'(2+3)^3',                 125",
        "'(1+1)^10',                1024",
        // operations on result of power
        "'2^3+1',                   9",
        "'2^3-1',                   7",
        "'2^3×2',                   16",
        // whitespace handled by tokenizer
        "'1 + 2',                   3",
        "' 1+2 ',                   3",
        "'1 +    2',                3",
        "'2 × 3 + 4',               10",
        // percent compositions
        "'100×(1+5%)',              105",
        "'100×(1-10%)',             90",
        // chain factorial in larger expression
        "'10+3!',                   16",
        "'3!+4!',                   30",
        "'3!×2',                    12",
        "'2×3!',                    12",
        // double-negation
        "'-(-(5))',                 5",
        "'-(-(2+3))',               5",
        // boundary integer factorials
        "'12!',                     479001600",
        "'14!',                     87178291200",
        // signed zero collapses
        "'-0',                      0",
        "'-0+5',                    5",
        "'5×-0',                    0",
        // power chains
        "'2^2^2',                   16",
        "'(2^2)^2',                 16",
        "'2^(2^2)',                 16",
        "'2^2^3',                   256",
    )
    fun exactArithmetic(expression: String, expected: String) {
        val value = rad.evaluate(expression).expectSuccess()
        assertEquals(
            0,
            value.compareTo(BigDecimal(expected)),
            "expected $expected but got $value",
        )
    }

    // ------------------------------------------------------------------
    // Transcendental cases: results compared within a tolerance because
    // the implementations route through Double.
    // ------------------------------------------------------------------

    @DisplayName("transcendentals in radians")
    @ParameterizedTest(name = "{0} ≈ {1}")
    @CsvSource(
        // exact zeros - the recent zero-snap fix must keep these clean
        "'sin(0)',                  0",
        "'sin(π)',                  0",
        "'cos(π÷2)',                0",
        "'tan(0)',                  0",
        "'tan(π)',                  0",
        "'asin(0)',                 0",
        "'atan(0)',                 0",
        "'log(1)',                  0",
        "'ln(1)',                   0",
        // exact ones
        "'cos(0)',                  1",
        "'sin(π÷2)',                1",
        "'log(10)',                 1",
        "'ln(e)',                   1",
        // exact integer outputs for common angles
        "'log(100)',                2",
        "'log(1000)',               3",
        "'log(0.01)',               -2",
        "'2^0.5×2^0.5',             2",
        // identities (within tolerance)
        "'sin(π÷6)',                0.5",
        "'cos(π÷3)',                0.5",
        "'tan(π÷4)',                1",
        "'sin(π÷4)',                0.70710678118654",
        "'asin(1)',                 1.5707963267948",
        "'acos(0)',                 1.5707963267948",
        "'acos(1)',                 0",
        "'atan(1)',                 0.78539816339744",
        // roots
        "'sqrt(0)',                 0",
        "'sqrt(1)',                 1",
        "'sqrt(4)',                 2",
        "'sqrt(9)',                 3",
        "'sqrt(2)',                 1.41421356237309",
        "'cbrt(0)',                 0",
        "'cbrt(8)',                 2",
        "'cbrt(27)',                3",
        "'cbrt(-8)',                -2",
        // exp/log identities
        "'ln(e^2)',                 2",
        // constants
        "'π',                       3.14159265358979",
        "'e',                       2.71828182845904",
        // power with fractional exponent
        "'8^(1÷3)',                 2",
        "'27^(1÷3)',                3",
        // function chaining
        "'sin(cos(0))',             0.84147098480789",
        "'cos(sin(0))',             1",
        "'sqrt(sqrt(16))',          2",
        "'log(sqrt(100))',          1",
        "'log(log(10))',            0",
        "'sin(asin(0.3))',          0.3",
        "'cos(acos(0.3))',          0.3",
        "'tan(atan(0.5))',          0.5",
        // mixed arithmetic + transcendentals
        "'sin(π÷2)+cos(0)',         2",
        "'sin(π)+cos(π)',           -1",
        "'2×sin(π÷6)',              1",
        "'log(10)+log(100)',        3",
        "'sqrt(9)+sqrt(16)',        7",
        // larger trig multiples (rad)
        "'sin(2×π)',                0",
        "'cos(2×π)',                1",
        "'sin(π÷6)+sin(π÷6)',       1",
        // log edge values
        "'log(1000000)',            6",
        "'log(0.001)',              -3",
        "'ln(1)',                   0",
        // exp / pow constants
        "'e^0',                     1",
        "'e^1',                     2.71828182845904",
        // sqrt edge values
        "'sqrt(0.25)',              0.5",
        "'sqrt(100)',               10",
        "'sqrt(10000)',             100",
        // cbrt around zero
        "'cbrt(0.125)',             0.5",
        "'cbrt(-0.125)',            -0.5",
        // arctan of large arg approaches π/2
        "'atan(1000000)',           1.5707953267948",
        // identity sin²+cos² = 1 at varied angles
        "'sin(1)^2+cos(1)^2',       1",
        "'sin(0.7)^2+cos(0.7)^2',   1",
        "'sin(π÷3)^2+cos(π÷3)^2',   1",
        "'sin(π÷5)^2+cos(π÷5)^2',   1",
        // double-angle: cos(2x) = cos²(x) - sin²(x)
        "'cos(2×0.5)',              0.54030230586813",
        "'cos(0.5)^2-sin(0.5)^2',   0.54030230586813",
        // negative exponent
        "'2^(-3)',                  0.125",
        "'10^(-2)',                 0.01",
        "'5^(-1)',                  0.2",
        // power of small base
        "'0.5^4',                   0.0625",
        "'0.1^3',                   0.001",
        // sqrt identities
        "'sqrt(2)×sqrt(2)',         2",
        "'sqrt(3)×sqrt(3)',         3",
        "'sqrt(2)^2',               2",
        "'sqrt(16)+sqrt(9)',        7",
        // log/ln identities
        "'log(10^5)',               5",
        "'ln(e^3)',                 3",
        "'log(10×10)',              2",
        "'ln(e×e)',                 2",
        "'log(100)-log(10)',        1",
        // π and e arithmetic
        "'π+0',                     3.14159265358979",
        "'π×1',                     3.14159265358979",
        "'π×2',                     6.28318530717958",
        "'π÷2',                     1.57079632679489",
        "'π-π',                     0",
        "'π÷π',                     1",
        "'e×1',                     2.71828182845904",
        "'e-e',                     0",
        "'e÷e',                     1",
        "'e^2',                     7.38905609893065",
        "'π^2',                     9.86960440108935",
        // function-of-arithmetic
        "'sin(1+1)',                0.90929742682568",
        "'log(10×10)',              2",
        "'sqrt(2+2)',               2",
        // deeply nested functions
        "'sqrt(sqrt(sqrt(256)))',   2",
        "'cos(cos(cos(0)))',        0.85755321584639",
        // 0^0 - JDK Math.pow(0,0) returns 1, matching most calculators
        "'0^0',                     1",
        // exp / log domain edges that are still valid
        "'log(0.1)',                -1",
        "'ln(1÷e)',                 -1",
    )
    fun transcendentalsRadians(expression: String, expected: String) {
        val value = rad.evaluate(expression).expectSuccess()
        assertNear(value, expected)
    }

    @DisplayName("transcendentals in degrees")
    @ParameterizedTest(name = "deg {0} ≈ {1}")
    @CsvSource(
        // degree-mode favourites - exact rationals
        "'sin(0)',                  0",
        "'sin(30)',                 0.5",
        "'sin(90)',                 1",
        "'sin(180)',                0",
        "'cos(0)',                  1",
        "'cos(60)',                 0.5",
        "'cos(90)',                 0",
        "'cos(180)',                -1",
        "'tan(0)',                  0",
        "'tan(45)',                 1",
        "'tan(180)',                0",
        // inverse, returning degrees
        "'asin(0)',                 0",
        "'asin(0.5)',               30",
        "'asin(1)',                 90",
        "'acos(0)',                 90",
        "'acos(1)',                 0",
        "'atan(1)',                 45",
        // extreme angles in degrees
        "'sin(270)',                -1",
        "'sin(360)',                0",
        "'sin(720)',                0",
        "'cos(270)',                0",
        "'cos(360)',                1",
        "'cos(-90)',                0",
        "'sin(-30)',                -0.5",
        "'cos(-60)',                0.5",
        "'tan(-45)',                -1",
        "'tan(135)',                -1",
        // 30/60/90 triangle multiples
        "'sin(30)+sin(60)',         1.3660254037844",
        "'cos(30)+cos(60)',         1.3660254037844",
        // asin/acos inverse
        "'asin(-0.5)',              -30",
        "'asin(-1)',                -90",
        "'acos(-1)',                180",
        "'acos(0.5)',               60",
        "'atan(-1)',                -45",
        // Pythagorean identity in degrees
        "'sin(30)^2+cos(30)^2',     1",
        "'sin(45)^2+cos(45)^2',     1",
        "'sin(60)^2+cos(60)^2',     1",
        // function chains
        "'sin(asin(0.7))',          0.7",
        "'cos(acos(0.4))',          0.4",
        "'asin(sin(40))',           40",
        "'acos(cos(50))',           50",
        // complement identities sin(x) = cos(90-x)
        "'sin(20)',                 0.34202014332566",
        "'cos(70)',                 0.34202014332566",
        "'sin(75)',                 0.96592582628906",
        "'cos(15)',                 0.96592582628906",
        // tan(45-x) for varied x stays finite
        "'tan(44)',                 0.96568877480707",
        "'tan(46)',                 1.03553031379057",
        // larger full-rotation behaviour
        "'sin(450)',                1",
        "'cos(450)',                0",
        "'sin(-180)',               0",
    )
    fun transcendentalsDegrees(expression: String, expected: String) {
        val value = deg.evaluate(expression).expectSuccess()
        assertNear(value, expected)
    }

    // ------------------------------------------------------------------
    // Error cases: every row asserts a specific [Error] subtype is
    // returned (never thrown, per the engine's documented contract).
    // ------------------------------------------------------------------

    /**
     * Degree-mode error case: tan(90°) at the asymptote. 90.0 is an
     * exact Double, so Math.tan returns Infinity and the engine's
     * isInfinite() check fires correctly. (In radian mode the same
     * angle - π/2 - is approximated and Math.tan returns a huge but
     * finite value, so radian asymptotes don't reliably trip this
     * branch and aren't catalogued here.)
     */
    @org.junit.jupiter.api.Test
    fun tan90DegreesIsDomainError() {
        val result = deg.evaluate("tan(90)")
        assertInstanceOf(EvaluationResult.Error.Domain::class.java, result)
    }

    @org.junit.jupiter.api.Test
    fun tan270DegreesIsDomainError() {
        val result = deg.evaluate("tan(270)")
        assertInstanceOf(EvaluationResult.Error.Domain::class.java, result)
    }

    @DisplayName("error paths")
    @ParameterizedTest(name = "{0} -> {1}")
    @CsvSource(
        // division by zero
        "'1÷0',                     DivisionByZero",
        "'0÷0',                     DivisionByZero",
        "'(1+2)÷0',                 DivisionByZero",
        // syntax
        "'(1+2',                    Syntax",
        "'1+2)',                    Syntax",
        "'1+',                      Syntax",
        "'×3',                      Syntax",
        "'',                        Syntax",
        // domain errors
        "'sqrt(-1)',                Domain",
        "'sqrt(-9)',                Domain",
        "'log(0)',                  Domain",
        "'log(-1)',                 Domain",
        "'ln(0)',                   Domain",
        "'ln(-1)',                  Domain",
        "'asin(2)',                 Domain",
        "'asin(-2)',                Domain",
        "'acos(2)',                 Domain",
        "'acos(-2)',                Domain",
        "'(-3)!',                   Domain",
        "'1001!',                   Domain",
        "'1.5!',                    Domain",
        "'(-0.5)!',                 Domain",
        "'10000!',                  Domain",
        // power producing infinity (Math.pow overflow at ~1e308)
        "'10^1000',                 Domain",
        // syntax: empty parens, lonely operators, double dots
        "'()',                      Syntax",
        "'(())',                    Syntax",
        // 5..5: the second `.` starts a "number" that's just a dot,
        // which the tokenizer reports as UnknownToken rather than Syntax.
        "'5..5',                    UnknownToken",
        "'1++1',                    Syntax",
        "'1+×1',                    Syntax",
        // unsupported chars
        "'1+a',                     UnknownToken",
        "'$5',                      UnknownToken",
        "'1#1',                     UnknownToken",
        // division by very-small produces a valid (large) result, not an
        // error - assert it doesn't error here is a positive case, but
        // include the literal 0 ones that are
        "'5÷0÷5',                   DivisionByZero",
        "'1÷(1-1)',                 DivisionByZero",
        "'1÷(2-2)',                 DivisionByZero",
        // negative-base fractional exponent: Math.pow returns NaN
        "'(-2)^0.5',                Domain",
        "'(-1)^0.5',                Domain",
        "'(-4)^0.25',               Domain",
        // factorial of fractional value
        "'2.5!',                    Domain",
        "'0.5!',                    Domain",
        // tan at asymptotes (π/2 + kπ): the engine detects these by
        // checking cos(arg) for near-zero, not by relying on isInfinite,
        // because Math.tan returns a huge finite value (~1.6e16) rather
        // than Infinity at these inputs. Both radian and degree forms
        // are caught.
        "'tan(π÷2)',                Domain",
        "'tan(3×π÷2)',              Domain",
    )
    fun errorPaths(expression: String, kind: String) {
        val result = rad.evaluate(expression)
        when (kind) {
            "DivisionByZero" ->
                assertInstanceOf(EvaluationResult.Error.DivisionByZero::class.java, result)

            "Syntax" ->
                assertInstanceOf(EvaluationResult.Error.Syntax::class.java, result)

            "Domain" ->
                assertInstanceOf(EvaluationResult.Error.Domain::class.java, result)

            "UnknownToken" ->
                assertInstanceOf(EvaluationResult.Error.UnknownToken::class.java, result)

            else -> error("unknown error kind: $kind")
        }
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private fun EvaluationResult.expectSuccess(): BigDecimal {
        assertInstanceOf(
            EvaluationResult.Success::class.java,
            this,
            "expected Success but got $this",
        )
        return (this as EvaluationResult.Success).value
    }

    /**
     * BigDecimal compare with an absolute tolerance. 1e-10 catches the
     * Double-precision wobble in the last 5-6 digits without letting
     * genuinely wrong results through.
     */
    private fun assertNear(
        actual: BigDecimal,
        expected: String,
        tolerance: Double = 1e-10,
    ) {
        val diff = (actual - BigDecimal(expected)).abs().toDouble()
        assert(diff < tolerance) {
            "expected $expected (±$tolerance) but got $actual (diff $diff)"
        }
    }
}
