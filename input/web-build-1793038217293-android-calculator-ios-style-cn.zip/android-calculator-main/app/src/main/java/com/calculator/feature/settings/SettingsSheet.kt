package com.calculator.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.calculator.BuildConfig
import com.calculator.R
import com.calculator.core.data.settings.UserSettings

/**
 * Settings sheet shown when the user taps the Settings tile in the tools
 * menu. Lists the persisted user preferences with iOS-style controls
 * (rounded rows, accent-colored switches, segmented theme picker).
 *
 * Writes go straight through the ViewModel into [SettingsRepository] -
 * Compose collects the resulting StateFlow so the UI always reflects
 * the latest persisted state.
 *
 * @param onLaunchFloating Starts the floating calculator overlay. The app
 *   shell owns that feature, so the sheet only reports the tap.
 */
@Composable
fun SettingsSheetContent(
    onLaunchFloating: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val settings = viewModel.settings.collectAsStateWithLifecycle().value ?: return
    val accent = MaterialTheme.colorScheme.primary
    val uriHandler = LocalUriHandler.current

    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            text = stringResource(R.string.settings_title),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(start = 8.dp, end = 8.dp, bottom = 16.dp),
        )

        // Theme picker - segmented "System / Light / Dark".
        SectionLabel(stringResource(R.string.settings_section_appearance))
        SegmentedThemePicker(
            selected = settings.theme,
            onSelect = viewModel::setTheme,
            accent = accent,
        )
        Spacer(Modifier.size(8.dp))
        ToggleRow(
            label = stringResource(R.string.settings_dynamic_color),
            description = stringResource(R.string.settings_dynamic_color_desc),
            checked = settings.dynamicColor,
            onCheckedChange = viewModel::setDynamicColor,
            accent = accent,
        )

        // Feedback.
        Spacer(Modifier.size(16.dp))
        SectionLabel(stringResource(R.string.settings_section_feedback))
        ToggleRow(
            label = stringResource(R.string.settings_haptics),
            description = stringResource(R.string.settings_haptics_desc),
            checked = settings.haptics,
            onCheckedChange = viewModel::setHaptics,
            accent = accent,
        )
        Spacer(Modifier.size(4.dp))
        ToggleRow(
            label = stringResource(R.string.settings_sound),
            description = stringResource(R.string.settings_sound_desc),
            checked = settings.sound,
            onCheckedChange = viewModel::setSound,
            accent = accent,
        )

        // Precision slider.
        Spacer(Modifier.size(16.dp))
        SectionLabel(stringResource(R.string.settings_section_precision))
        PrecisionRow(
            precision = settings.precision,
            onChange = viewModel::setPrecision,
            accent = accent,
        )

        // Floating calculator.
        Spacer(Modifier.size(16.dp))
        SectionLabel(stringResource(R.string.settings_section_floating))
        ActionRow(
            label = stringResource(R.string.settings_floating_launch),
            description = stringResource(R.string.settings_floating_desc),
            onClick = onLaunchFloating,
        )

        // About.
        Spacer(Modifier.size(16.dp))
        SectionLabel(stringResource(R.string.settings_section_about))
        AboutRow(
            label = stringResource(R.string.settings_about_version),
            // Read from the build instead of a hardcoded string so the row
            // always tracks the shipped versionName/versionCode (debug
            // builds show the "-debug" suffix from versionNameSuffix).
            value = "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
        )
        AboutRow(
            label = stringResource(R.string.settings_about_license),
            value = stringResource(R.string.settings_about_license_value),
        )
        val githubHandle = stringResource(R.string.settings_about_github_value)
        AboutRow(
            label = stringResource(R.string.settings_about_github),
            value = githubHandle,
            onClick = { uriHandler.openUri("https://github.com/$githubHandle") },
        )

        Spacer(Modifier.size(24.dp))
    }
}

/**
 * Small uppercase header above each settings group (Appearance,
 * Feedback, etc.). Matches the iOS Settings app convention; uppercase
 * is done at render time so callers pass plain title-case strings.
 */
@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 16.dp, bottom = 6.dp),
    )
}

/**
 * Tappable row with a label, optional description, and trailing switch.
 *
 * The whole row is clickable, not just the switch - matches the iOS
 * pattern where tapping anywhere on the cell toggles the value. The
 * switch's own `onCheckedChange` covers the case where the user drags
 * the thumb instead of tapping.
 *
 * @param label Primary row label.
 * @param description Optional second line; pass null to skip.
 * @param checked Current switch state.
 * @param onCheckedChange Invoked with the new value when the row or
 *   switch is tapped.
 * @param accent Track colour when checked - reused by the slider and
 *   theme picker so the whole sheet has one accent.
 */
@Composable
private fun ToggleRow(
    label: String,
    description: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    accent: Color,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .clickable { onCheckedChange(!checked) }
                .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
            if (description != null) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors =
                SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                    checkedTrackColor = accent,
                    uncheckedThumbColor = MaterialTheme.colorScheme.outline,
                    uncheckedTrackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                    uncheckedBorderColor = Color.Transparent,
                ),
        )
    }
}

/**
 * Tappable row that fires an action (no persistent toggle). Same chrome
 * as [ToggleRow] minus the trailing switch so the two read as the same
 * family of cells in the settings sheet.
 */
@Composable
private fun ActionRow(
    label: String,
    description: String?,
    onClick: () -> Unit,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
            if (description != null) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Text(
            text = "›",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun SegmentedThemePicker(
    selected: UserSettings.ThemeOption,
    onSelect: (UserSettings.ThemeOption) -> Unit,
    accent: Color,
) {
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        UserSettings.ThemeOption.entries.forEach { option ->
            val isSelected = option == selected
            Text(
                text = stringResource(option.labelRes()),
                style = MaterialTheme.typography.bodyMedium,
                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                modifier =
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) accent else Color.Transparent)
                        .clickable { onSelect(option) }
                        .padding(vertical = 10.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
}

/**
 * Significant-figures slider.
 *
 * Steps are the integer count within [UserSettings.PRECISION_RANGE].
 * Slider's `steps` value is "tick marks between min and max" (exclusive
 * of both endpoints), so it's `(max - min) - 1`.
 *
 * Picked-up changes flow through the settings repository and the
 * Evaluator instances pull the new precision on their next construction
 * - precision changes take effect on the next keypress, no restart.
 */
@Composable
private fun PrecisionRow(
    precision: Int,
    onChange: (Int) -> Unit,
    accent: Color,
) {
    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(R.string.settings_precision_label),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = precision.toString(),
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                color = accent,
            )
        }
        Slider(
            value = precision.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange =
                UserSettings.PRECISION_RANGE.first.toFloat()..UserSettings.PRECISION_RANGE.last.toFloat(),
            steps = UserSettings.PRECISION_RANGE.last - UserSettings.PRECISION_RANGE.first - 1,
            colors =
                SliderDefaults.colors(
                    thumbColor = accent,
                    activeTrackColor = accent,
                    inactiveTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f),
                    activeTickColor = Color.Transparent,
                    inactiveTickColor = Color.Transparent,
                ),
        )
        Text(
            text = stringResource(R.string.settings_precision_description),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/**
 * Label-value row in the About section. When [onClick] is non-null the
 * whole row is tappable and the value renders in the accent colour to
 * signal it's a link (e.g. the GitHub row opens the repo in a browser).
 */
@Composable
private fun AboutRow(label: String, value: String, onClick: (() -> Unit)? = null) {
    Column {
        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
                    .padding(horizontal = 16.dp, vertical = 14.dp),
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                color = if (onClick != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        HorizontalDivider(
            color = MaterialTheme.colorScheme.outlineVariant,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
    }
}

private fun UserSettings.ThemeOption.labelRes(): Int =
    when (this) {
        UserSettings.ThemeOption.System -> R.string.settings_theme_system
        UserSettings.ThemeOption.Light -> R.string.settings_theme_light
        UserSettings.ThemeOption.Dark -> R.string.settings_theme_dark
    }

@Suppress("unused")
private val PaddingPlaceholder = PaddingValues(0.dp)
