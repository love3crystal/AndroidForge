package com.calculator.core.designsystem.component

import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.calculator.R
import com.calculator.core.common.input.InputResult

/**
 * Shared page shell for every tool screen: themed canvas, a title row
 * with the menu button on the right, and a body column.
 *
 * The menu itself is hosted once by the app shell; this composable only
 * draws the button and reports the tap through [onOpenMenu]. The button
 * sits at the same spot as on the basic calculator, so it does not jump
 * when the user moves between pages.
 *
 * @param title Screen title shown left of the menu button.
 * @param onOpenMenu Invoked when the menu button is tapped.
 * @param actions Extra icon buttons shown before the menu button.
 * @param scrollable True to scroll the body as one column. Pass false
 *   when the body has its own lazy list or fills the height itself.
 * @param content Body of the screen. Receives a [ColumnScope] so cards
 *   can use `Modifier.weight` if they need to.
 */
@Composable
fun LifeCalculatorScaffold(
    title: String,
    onOpenMenu: () -> Unit,
    actions: @Composable RowScope.() -> Unit = {},
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .background(scheme.background)
                .systemBarsPadding()
                // Horizontal 12dp matches the basic calculator's outer
                // padding so the top-right hamburger lands at the same
                // pixel across screens (no visible icon jump when the
                // user navigates between basic calc and a tool).
                .padding(horizontal = 12.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                color = scheme.onBackground,
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
            actions()
            IconButton(onClick = onOpenMenu) {
                Icon(
                    imageVector = Icons.Filled.Menu,
                    contentDescription = stringResource(R.string.basic_open_menu),
                    tint = scheme.onBackground,
                )
            }
        }
        if (scrollable) {
            Column(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                content()
                Spacer(Modifier.size(24.dp))
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) { content() }
        }
    }
}

/** A bordered "card" container; use for grouping inputs or outputs. */
@Composable
fun LifeCalcCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier =
            modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceContainer)
                .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) { content() }
}

/** Inline section title rendered inside a card. */
@Composable
fun LifeCalcSectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

/**
 * Labelled number field with the same iOS-flavoured look as the rest
 * of the app: dim white label, white bold value, decimal IME.
 *
 * Uses [BasicTextField] (not OutlinedTextField) because the visual is a
 * borderless label-over-value pattern - the M3 text field would impose
 * its own outline and floating label which don't match.
 *
 * @param label Field title shown above the value.
 * @param value Current value as a string. The caller is responsible for
 *   parsing it - strings let mid-edit states like "" or "-." round-trip
 *   without prematurely converting.
 * @param onValueChange Invoked on each keystroke with the new string.
 * @param suffix Optional trailing unit (e.g. "kg", "%"). Rendered to the
 *   right of the field at smaller weight so the number reads as primary.
 * @param error Message shown under the field when its value is wrong.
 */
@Composable
fun LifeCalcNumberField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    suffix: String? = null,
    error: String? = null,
) {
    val scheme = MaterialTheme.colorScheme
    Column {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle =
                MaterialTheme.typography.headlineMedium.copy(
                    color = scheme.onSurface,
                    fontWeight = FontWeight.Bold,
                ),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            cursorBrush = androidx.compose.ui.graphics
                .SolidColor(scheme.primary),
            modifier = Modifier.fillMaxWidth(),
            // The label and unit are drawn inside the field, so screen
            // readers read them with the typed value as one edit box.
            decorationBox = { innerTextField ->
                Column {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.size(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { innerTextField() }
                        if (suffix != null) {
                            Text(
                                text = suffix,
                                style = MaterialTheme.typography.titleMedium,
                                color = scheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }
            },
        )
        if (error != null) {
            Text(
                text = error,
                style = MaterialTheme.typography.bodySmall,
                color = scheme.error,
            )
        }
    }
}

/**
 * The message for [field] when this result says that field is wrong,
 * or null. Pass it as a number field's `error`.
 */
@Suppress("SpreadOperator") // copies at most two format arguments, only while a field is wrong
@Composable
fun InputResult<*>.errorFor(
    @StringRes field: Int,
): String? =
    (this as? InputResult.Invalid)
        ?.takeIf { it.field == field }
        ?.let { stringResource(it.message, *it.args.toTypedArray()) }

/**
 * "Label .... value" output line; used in result cards.
 *
 * Layout: label on the left at 70% white, value right-aligned and bold.
 * Setting [accent] to true colors the value with the orange accent and
 * bumps the weight to bold - used to mark the headline output of each
 * calculator (EMI, BMI, gross, etc.) so the user's eye lands on it first.
 *
 * @param label Row label (e.g. "Monthly EMI").
 * @param value Right-aligned value string.
 * @param accent If true, render the value in the orange accent colour.
 */
@Composable
fun LifeCalcOutputRow(label: String, value: String, accent: Boolean = false) {
    val scheme = MaterialTheme.colorScheme
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = scheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = value,
            style =
                MaterialTheme.typography.titleLarge.copy(
                    fontWeight = if (accent) FontWeight.Bold else FontWeight.SemiBold,
                ),
            color = if (accent) scheme.primary else scheme.onSurface,
            textAlign = TextAlign.End,
        )
    }
}

/**
 * Two-option segmented control. Use for toggles like Metric/Imperial,
 * Forward/Reverse, Intra-state/Inter-state.
 *
 * The component accepts N options but visually it's tuned for 2 - with
 * 3+ the labels can get crowded on narrow screens. The selected pill
 * uses the orange accent with black text (high-contrast on the bright
 * fill); unselected segments are transparent with white text.
 *
 * @param options Labels for each segment, left-to-right.
 * @param selectedIndex 0-based index of the currently-selected option.
 * @param onSelect Invoked with the tapped segment's index.
 */
@Composable
fun LifeCalcSegmented(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(scheme.surfaceContainerHigh)
                .padding(4.dp)
                .selectableGroup(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEachIndexed { idx, opt ->
            val selected = idx == selectedIndex
            Box(
                modifier =
                    Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) scheme.primary else Color.Transparent)
                        // Read as one radio button of a group, with its state.
                        .selectable(selected = selected, role = Role.RadioButton) { onSelect(idx) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = opt,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (selected) scheme.onPrimary else scheme.onSurface,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}
