# 中文 iOS 风格定制版

基于 `zeevy/android-calculator` 的定制版本。

## 本次修改

- 基础计算器按键改为接近 iPhone 计算器布局：
  - AC / ± / % / ÷
  - 7 / 8 / 9 / ×
  - 4 / 5 / 6 / −
  - 1 / 2 / 3 / +
  - 0（双宽）/ . / =
- AC 点击：清除当前输入，**不删除上方计算纸带历史**。
- AC 长按：退格，方便修改当前输入。
- 保留原项目的多行 inline tape、历史结果点击调用、可编辑历史和科学计算。
- 增加简体中文资源（`values-zh-rCN`）。
- 科学模式仍保留原有科学计算和内存功能。

## 构建

这是完整 Gradle Android 项目，可使用 Android Studio 或 GitHub Actions 构建。
